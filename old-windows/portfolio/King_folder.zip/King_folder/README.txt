***********************
King Consultant Website
***********************

To View the Website, just open it in google chrome: 
  Right click on 'index.html' 
  Choose 'Open with' 
  Click chrome

To view the site's source code, open the desired file 
in a text editor or in a code editor.

