﻿using System;

namespace csCalculator
{
    class Program
    {
        public static void Main(string[] args)
        {
            input();
        }

        public static void input()
        {
            float a = 0, b = 0;
            char c = 'a';

            try
            {
                Console.Write("Enter an operator (+-*/): ");
                c = char.Parse(Console.ReadLine());

                if (c == '+' || c == '-' || c == '*' || c == '/')
                {
                    
                }
                else
                {
                    Console.Write("Wrong input: 1");
                    Console.ReadKey();
                    Console.Clear();
                    input();
                }

                Console.Write("Enter your first desired number: ");
                a = float.Parse(Console.ReadLine());
                
                Console.Write("Enter your second desired number: ");
                b = float.Parse(Console.ReadLine());
            }
            catch (Exception e)
            {
                Console.Write("Wrong input: 2");
                Console.ReadKey();
                Console.Clear();
                input();
            }
            

            Math.decision(a, b, c);
        }

        public static void output(float d)
        {
            string e = "q";

            Console.WriteLine(d);

            Console.Write("\n" + "Do you want to start again? (y/n): ");

            e = Console.ReadLine();

            if (e == "y" || e == "Y" || e == "yes" || e == "Yes" || e == "YES")
            {
                Console.Clear();
                input();
            }
            else
            {

            }
        }
    }

    public class Math
    {
        public static void decision(float a, float b, char c)
        {
            if (c == '+')
            {
                addition(a, b, c);
            }
            else if (c == '-')
            {
                subtraction(a, b, c);
            }
            else if(c == '*')
            {
                multiplication(a, b, c);
            }
            else if(c == '/')
            {
                division(a, b, c);
            }
        }

        static void addition(float a, float b, char c)
        {
            float d = a + b;
            Program.output(d);
        }

        static void subtraction(float a, float b, char c)
        {
            float d = a - b;
            Program.output(d);
        }

        static void multiplication(float a, float b, char c)
        {
            float d = a * b;
            Program.output(d);
        }

        static void division(float a, float b, char c)
        {
            float d = a / b;
            Program.output(d);
        }

    }
}

