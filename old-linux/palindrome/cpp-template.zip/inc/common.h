#ifndef COMMON_H
#define COMMON_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <random>
#include <thread>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#endif
